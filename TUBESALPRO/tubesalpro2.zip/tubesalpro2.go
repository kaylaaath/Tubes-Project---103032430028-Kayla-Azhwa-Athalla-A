package main

import "fmt"

type Content struct {
	ID          int
	Title       string
	Category    string
	Platform    string
	Schedule    string
	Likes       int
	Comments    int
	Shares      int
	Description string
}

var contents [100]Content
var count, nextID int = 0, 1

func main() {
	for {
		fmt.Println("+----+-------------------------------------------+")
		fmt.Println("| No |               MENU UTAMA                  |")
		fmt.Println("+----+-------------------------------------------+")
		fmt.Println("| 1  | Tambah Ide Konten                         |")
		fmt.Println("| 2  | Edit Ide Konten                           |")
		fmt.Println("| 3  | Hapus Ide Konten                          |")
		fmt.Println("| 4  | Jadwalkan Konten                          |")
		fmt.Println("| 5  | Cari Ide Konten                           |")
		fmt.Println("| 6  | Urutkan Konten                            |")
		fmt.Println("| 7  | Tampilkan Engagement Tertinggi            |")
		fmt.Println("| 8  | Tampilkan Semua Konten                    |")
		fmt.Println("| 9  | Keluar                                    |")
		fmt.Println("+----+-------------------------------------------+")
		fmt.Print("Pilih menu: ")
		var menu int
		fmt.Scanln(&menu)
		switch menu {
		case 1:
			addContent()
		case 2:
			editContent()
		case 3:
			deleteContent()
		case 4:
			scheduleContent()
		case 5:
			searchContent()
		case 6:
			sortContent()
		case 7:
			showTopEngagement()
		case 8:
			showAllContents()
		case 9:
			fmt.Println("Terimakasih telah menggunakan aplikasi ini")
			return
		default:
			fmt.Println("Pilihan tidak valid!")
		}
	}
}

func addContent() {
	var c Content
	c.ID = nextID
	nextID++
	fmt.Print("Judul Konten: ")
	fmt.Scanln(&c.Title)
	fmt.Print("Kategori Konten: ")
	fmt.Scanln(&c.Category)
	fmt.Print("Deskripsi Konten: ")
	fmt.Scanln(&c.Description)
	fmt.Print("Platform: ")
	fmt.Scanln(&c.Platform)
	contents[count] = c
	count++
	fmt.Println("Konten berhasil ditambahkan!")
}

func editContent() {
	showAllContents()
	fmt.Print("ID konten yang diedit: ")
	var id int
	fmt.Scanln(&id)
	idx := findByID(id)
	if idx == -1 {
		fmt.Println("Konten tidak ditemukan!")
		return
	}
	c := &contents[idx]
	fmt.Print("Judul Baru (enter untuk lewati): ")
	var t string
	fmt.Scanln(&t)
	if t != "" {
		c.Title = t
	}
	fmt.Print("Kategori Baru (enter untuk lewati): ")
	var cat string
	fmt.Scanln(&cat)
	if cat != "" {
		c.Category = cat
	}
	fmt.Print("Deskripsi Baru (enter untuk lewati): ")
	var desc string
	fmt.Scanln(&desc)
	if desc != "" {
		c.Description = desc
	}
	fmt.Print("Platform Baru (enter untuk lewati): ")
	var plat string
	fmt.Scanln(&plat)
	if plat != "" {
		c.Platform = plat
	}
	fmt.Print("Update Likes (-1 lewati): ")
	var likes int
	fmt.Scanln(&likes)
	if likes >= 0 {
		c.Likes = likes
	}
	fmt.Print("Update Comments (-1 lewati): ")
	var com int
	fmt.Scanln(&com)
	if com >= 0 {
		c.Comments = com
	}
	fmt.Print("Update Shares (-1 lewati): ")
	var sh int
	fmt.Scanln(&sh)
	if sh >= 0 {
		c.Shares = sh
	}
	fmt.Println("Konten berhasil diubah!")
}

func deleteContent() {
	showAllContents()
	fmt.Print("ID konten yang dihapus: ")
	var id int
	fmt.Scanln(&id)
	idx := findByID(id)
	if idx == -1 {
		fmt.Println("Konten tidak ditemukan!")
		return
	}
	for i := idx; i < count-1; i++ {
		contents[i] = contents[i+1]
	}
	count--
	fmt.Println("Konten berhasil dihapus!")
}

func scheduleContent() {
	showAllContents()
	fmt.Print("ID konten yang dijadwalkan: ")
	var id int
	fmt.Scanln(&id)
	idx := findByID(id)
	if idx == -1 {
		fmt.Println("Konten tidak ditemukan!")
		return
	}
	fmt.Print("Jadwal posting: ")
	fmt.Scanln(&contents[idx].Schedule)
	fmt.Println("Jadwal berhasil disimpan!")
}

func searchContent() {
	fmt.Print("Cari berdasarkan (1) Judul/Deskripsi (2) Kategori: ")
	var opt int
	fmt.Scanln(&opt)
	fmt.Print("Kata kunci: ")
	var key string
	fmt.Scanln(&key)
	fmt.Print("Metode (1) Sequential (2) Binary: ")
	var met int
	fmt.Scanln(&met)
	if opt == 1 && met == 1 {
		for i := 0; i < count; i++ {
			if contents[i].Title == key || contents[i].Description == key {
				printContent(contents[i])
			}
		}
	} else if opt == 2 && met == 1 {
		for i := 0; i < count; i++ {
			if contents[i].Category == key {
				printContent(contents[i])
			}
		}
	} else if opt == 1 && met == 2 {
		selectionSortByTitle()
		low, high := 0, count-1
		for low <= high {
			mid := (low + high) / 2
			if contents[mid].Title == key {
				printContent(contents[mid])
				return
			} else if contents[mid].Title < key {
				low = mid + 1
			} else {
				high = mid - 1
			}
		}
		fmt.Println("Tidak ditemukan.")
	} else if opt == 2 && met == 2 {
		selectionSortByCategory()
		low, high := 0, count-1
		for low <= high {
			mid := (low + high) / 2
			if contents[mid].Category == key {
				printContent(contents[mid])
				return
			} else if contents[mid].Category < key {
				low = mid + 1
			} else {
				high = mid - 1
			}
		}
		fmt.Println("Tidak ditemukan.")
	}
}

func sortContent() {
	fmt.Print("Urutkan (1) Jadwal (2) Engagement: ")
	var f int
	fmt.Scanln(&f)
	fmt.Print("Metode (1) Selection (2) Insertion: ")
	var m int
	fmt.Scanln(&m)
	if f == 1 && m == 1 {
		selectionSortBySchedule()
	} else if f == 1 && m == 2 {
		insertionSortBySchedule()
	} else if f == 2 && m == 1 {
		selectionSortByEngagement()
	} else if f == 2 && m == 2 {
		insertionSortByEngagement()
	}
	showAllContents()
}

func showTopEngagement() {
	fmt.Print("Awal periode: ")
	var awal string
	fmt.Scanln(&awal)
	fmt.Print("Akhir periode: ")
	var akhir string
	fmt.Scanln(&akhir)
	max := -1
	idx := -1
	for i := 0; i < count; i++ {
		if contents[i].Schedule == "" {
			continue
		}
		tg := contents[i].Schedule
		if len(tg) < 10 {
			continue
		}
		t := tg[:10]
		if t >= awal && t <= akhir {
			total := contents[i].Likes + contents[i].Comments + contents[i].Shares
			if total > max {
				max = total
				idx = i
			}
		}
	}
	if idx != -1 {
		fmt.Println("Konten engagement tertinggi:")
		printContent(contents[idx])
	} else {
		fmt.Println("Tidak ada konten dalam periode itu.")
	}
}

func showAllContents() {
	fmt.Println("\n=== Daftar Konten ===")
	for i := 0; i < count; i++ {
		printContent(contents[i])
	}
}

func printContent(c Content) {
	fmt.Printf("ID:%d | Judul:%s | Kategori:%s | Platform:%s\n", c.ID, c.Title, c.Category, c.Platform)
	fmt.Printf("Jadwal:%s | Like:%d | Komentar:%d | Share:%d\n", c.Schedule, c.Likes, c.Comments, c.Shares)
	fmt.Printf("Deskripsi:%s\n", c.Description)
	fmt.Println("-----------------------------")
}

func findByID(id int) int {
	for i := 0; i < count; i++ {
		if contents[i].ID == id {
			return i
		}
	}
	return -1
}

// --- Sorting ---
func selectionSortByTitle() {
	for i := 0; i < count-1; i++ {
		min := i
		for j := i + 1; j < count; j++ {
			if contents[j].Title < contents[min].Title {
				min = j
			}
		}
		contents[i], contents[min] = contents[min], contents[i]
	}
}
func selectionSortByCategory() {
	for i := 0; i < count-1; i++ {
		min := i
		for j := i + 1; j < count; j++ {
			if contents[j].Category < contents[min].Category {
				min = j
			}
		}
		contents[i], contents[min] = contents[min], contents[i]
	}
}
func selectionSortBySchedule() {
	for i := 0; i < count-1; i++ {
		min := i
		for j := i + 1; j < count; j++ {
			if contents[j].Schedule < contents[min].Schedule {
				min = j
			}
		}
		contents[i], contents[min] = contents[min], contents[i]
	}
}
func selectionSortByEngagement() {
	for i := 0; i < count-1; i++ {
		max := i
		for j := i + 1; j < count; j++ {
			a := contents[j].Likes + contents[j].Comments + contents[j].Shares
			b := contents[max].Likes + contents[max].Comments + contents[max].Shares
			if a > b {
				max = j
			}
		}
		contents[i], contents[max] = contents[max], contents[i]
	}
}
func insertionSortBySchedule() {
	for i := 1; i < count; i++ {
		key := contents[i]
		j := i - 1
		for j >= 0 && contents[j].Schedule > key.Schedule {
			contents[j+1] = contents[j]
			j--
		}
		contents[j+1] = key
	}
}
func insertionSortByEngagement() {
	for i := 1; i < count; i++ {
		key := contents[i]
		keyEng := key.Likes + key.Comments + key.Shares
		j := i - 1
		for j >= 0 && (contents[j].Likes+contents[j].Comments+contents[j].Shares) < keyEng {
			contents[j+1] = contents[j]
			j--
		}
		contents[j+1] = key
	}
}